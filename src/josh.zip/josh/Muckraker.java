package josh;

import battlecode.common.RobotController;

public class Muckraker extends Robot {

	public Muckraker(RobotController r) {
		super(r);
	}

}
